import mongoose, { Schema } from "mongoose";

const comment = new mongoose.Schema(
  {
    comment: { type: String, required: true },
    user: { type: Schema.Types.ObjectId, ref: "user", required: true },
    likes: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    dislikes: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    product: {
      type: Schema.Types.ObjectId,
      ref: "product",
      required: true,
    },
    isApproved: {
      type: Boolean,
      default: false,
    },
    isBan: {
      type: Boolean,
      required: false,
    },
    likesCount: {
      type: Number,
      default: 0,
    },
    dislikesCount: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
  },
);

const commentModel =
  mongoose.models.comment || mongoose.model("comment", comment);

export default commentModel;
