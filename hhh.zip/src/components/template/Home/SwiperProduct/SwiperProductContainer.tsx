"use client";

import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import SwiperProduct from "./SwiperProduct";


function SwiperProductContainer({ products }: any) {
  return (
      <div className="w-full overflow-hidden mt-5 ">
        <Swiper
          slidesPerView={4.5}
          spaceBetween={20}
          breakpoints={{
            320: { slidesPerView: 1.5, spaceBetween: 14 },
            640: { slidesPerView: 2, spaceBetween: 16 },
            768: { slidesPerView: 3, spaceBetween: 18 },
            1024: { slidesPerView: 4, spaceBetween: 20 },
            1280: { slidesPerView: 4.5, spaceBetween: 20 },
          }}
          className="mySwiper !h-[390px]"
        >
          {products?.map((product: any) => (
            <SwiperSlide key={product._id}>
              <SwiperProduct product={product} />
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
  );
}

export default SwiperProductContainer;
